﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using DatabaseInventoryWebAPI.Models;
using System.Web.Http.Cors;

namespace DatabaseInventoryWebAPI.Models
{

    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class ServerController : ApiController
    {
        private List<Server> serverlist = new List<Server>() {
            new Server { ServerID = 1, PlantID = 1, IPAddress = "123.2.1.4563", ServerType = "Production", DatabaseName = "Sterling Height Production", DatabaseUserName = "sterlingheightprod", DatabasePassword="ijcoresterlingheightprod"}, 
            new Server { ServerID = 2, PlantID = 1, IPAddress = "421.5.1.1235", ServerType = "Sandbox", DatabaseName = "Sterling Height Sandbox", DatabaseUserName = "sterlingheightsand", DatabasePassword="ijcoresterlingheightsand" },
            new Server { ServerID = 3, PlantID = 2, IPAddress = "512.4.2.0214", ServerType = "Production", DatabaseName = "Plymouth Production", DatabaseUserName = "plymouthprod", DatabasePassword="ijcoreplymouthprod"},
            new Server { ServerID = 4, PlantID = 3, IPAddress = "985.1.3.5248", ServerType = "Sandbox", DatabaseName = "Auburn Hills Sandbox", DatabaseUserName = "auburnhillssand", DatabasePassword="ijcoreauburnhillssand" },
            new Server { ServerID = 5, PlantID = 3, IPAddress = "753.4.6.5269", ServerType = "Production", DatabaseName = "Auburn Hills Production", DatabaseUserName = "auburnhillsprod", DatabasePassword="ijcoreauburnhillsprod"},
            new Server { ServerID = 6, PlantID = 4, IPAddress = "102.3.7.6875", ServerType = "Sandbox", DatabaseName = "Ontario Sandbox", DatabaseUserName = "ontariosand", DatabasePassword="ijcoreontariosand" },
            new Server { ServerID = 7, PlantID = 4, IPAddress = "521.2.6.7569", ServerType = "Production", DatabaseName = "Ontario Production", DatabaseUserName = "ontarioprod", DatabasePassword="ijcoreontarioprod"}
        }; 
        // GET: api/Server
        public IEnumerable<Server> Get()
        {
            return serverlist; 
        }

        // GET: api/Server/5
        public Server Get(int id)
        {
            for (int i = 0; i < serverlist.Count; i++)
            {
                if (serverlist[i].ServerID == id)
                {
                    return serverlist[i];
                }
            }
            return null;
        }

        // POST: api/Server
        public void Post([FromBody]Server value)
        {
            //replace peopleid with the id that is the latest this will ensure that the id is unique
            value.ServerID = serverlist[serverlist.Count].ServerID++;
            serverlist.Add(value);
        }

        // PUT: api/Server/5
        public void Put(int id, [FromBody]Server value)
        {
            for (int i = 0; i <= serverlist.Count; i++)
            {
                if (serverlist[i].ServerID == id)
                {
                    serverlist[i].IPAddress = value.IPAddress;
                    serverlist[i].ServerType = value.ServerType;
                    serverlist[i].DatabaseName = value.DatabaseName;
                    serverlist[i].DatabaseUserName = value.DatabaseUserName;
                    serverlist[i].DatabasePassword = value.DatabasePassword; 
                }
            }
        }

        // DELETE: api/Server/5
        public void Delete(int id)
        {
            for (int i = 0; i <= serverlist.Count; i++)
            {
                if (serverlist[i].ServerID == id)
                {
                    serverlist.Remove(serverlist[i]);
                    break;
                }
            }
        }
    }
}
