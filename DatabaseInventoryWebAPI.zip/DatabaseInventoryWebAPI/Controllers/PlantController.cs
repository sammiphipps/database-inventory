﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using DatabaseInventoryWebAPI.Models;
using System.Web.Http.Cors;

namespace DatabaseInventoryWebAPI.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class PlantController : ApiController
    {
        private List<Plant> plantlist = new List<Plant>() {
            new Plant { PlantID = 1, SiteName = "Sterling Heights (STE)", Program = "Seating", BusinessGroup = "FIS", Address = "6100 Sims Dr, Sterling Heights, MI 48313", Country = "United States", Software = "IJCore v1.1.5", RegionalManager = 1, BusinessAnalyst = 2, LocalIT = 3},
            new Plant { PlantID = 2, SiteName = "Plymouth (PLY)", Program = "Engines", BusinessGroup = "FES", Address = "44675 Helm Ct, Plymouth, MI 48170", Country = "United States", Software = "IJCore v1.1.3", RegionalManager = 1, BusinessAnalyst = 0, LocalIT = 0},
            new Plant { PlantID = 3, SiteName = "Auburn Hills (AH)", Program = "Tech", BusinessGroup = "", Address = "Featherstone Rd, Auburn Hills, MI 48326", Country = "United States", Software = "IJCore v1.1.5", RegionalManager = 1, BusinessAnalyst = 3, LocalIT = 3},
            new Plant { PlantID = 4, SiteName = "Ontario (ONT)", Program = "Interior", BusinessGroup = "FIS", Address = " 40 Summerlea Rd, Brampton, ON L6T 4X3", Country = "Canada", Software = "IJCore v1.1.6", RegionalManager = 4, BusinessAnalyst = 5, LocalIT = 6},         
        }; 
        // GET: api/Plant
        public IEnumerable<Plant> Get()
        {
            return plantlist; 
        }

        // GET: api/Plant/5
        public Plant Get(int id)
        {
            for(int i = 0; i < plantlist.Count; i++)
            {
                if (plantlist[i].PlantID == id)
                {
                    return plantlist[i];
                }       
            }
            return null;
        }

        // POST: api/Plant
        public void Post([FromBody]Plant value)
        {
            //replace plantid with the id that is the latest, this will ensure that the id is unique
            value.PlantID = plantlist[plantlist.Count].PlantID++;
            plantlist.Add(value);
        }

        // PUT: api/Plant/5
        public void Put(int id, [FromBody]Plant value)
        {
            for(int i = 0; i <= plantlist.Count; i++)
            {
                if(plantlist[i].PlantID == id)
                {
                    plantlist[i].SiteName = value.SiteName;
                    plantlist[i].Program = value.Program;
                    plantlist[i].BusinessGroup = value.BusinessGroup;
                    plantlist[i].Address = value.Address;
                    plantlist[i].Country = value.Country;
                    plantlist[i].Software = value.Software;
                    plantlist[i].RegionalManager = value.RegionalManager;
                    plantlist[i].BusinessAnalyst = value.BusinessAnalyst;
                    plantlist[i].LocalIT = value.LocalIT;
                }
            }
        }

        // DELETE: api/Plant/5
        public void Delete(int id)
        {
            for(int i = 0; i <= plantlist.Count; i++)
            {
                if(plantlist[i].PlantID == id)
                {
                    plantlist.Remove(plantlist[i]);
                    break; 
                }
            }
        }
    }
}
