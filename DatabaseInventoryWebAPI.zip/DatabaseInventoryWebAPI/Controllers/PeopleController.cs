﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using DatabaseInventoryWebAPI.Models;
using System.Web.Http.Cors;

namespace DatabaseInventoryWebAPI.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class PeopleController : ApiController
    {
        private List<People> peoplelist = new List<People>() {
            new People { PersonID = 1, FirstName = "Joan", LastName = "Smith", OfficeNumber = "248-111-2222", MobileNumber="248-222-3333", Email = "joan.smith@company.com", RegionalManagerPosition = true, BusinessAnalystPosition = false, LocalITPosition = false},
            new People {PersonID = 2, FirstName = "Roger", LastName = "Jackson", OfficeNumber = "248-333-4444", MobileNumber = "248-444-5555", Email = "roger.jackson@company.com", RegionalManagerPosition = false, BusinessAnalystPosition = true, LocalITPosition = false },
            new People {PersonID = 3, FirstName = "Jack", LastName = "Black", OfficeNumber = "248-555-6666", MobileNumber = "248-666-7777",Email = "jack.black@company.com", RegionalManagerPosition = false, BusinessAnalystPosition = false, LocalITPosition = true },
            new People { PersonID = 4, FirstName = "Sarah", LastName = "Johnson", OfficeNumber = "248-777-8888", MobileNumber="248-888-9999", Email = "sarah.johnson@company.com", RegionalManagerPosition = true, BusinessAnalystPosition = false, LocalITPosition = false},
            new People {PersonID = 5, FirstName = "Luis", LastName = "White", OfficeNumber = "248-888-9999", MobileNumber = "248-121-2323", Email = "luis.white@company.com", RegionalManagerPosition = false, BusinessAnalystPosition = true, LocalITPosition = false },
            new People {PersonID = 6, FirstName = "Mary", LastName = "Anderson", OfficeNumber = "248-232-3434", MobileNumber = "248-343-4545",Email = "mary.anderson@company.com", RegionalManagerPosition = false, BusinessAnalystPosition = false, LocalITPosition = true }
        }; 
        // GET: api/People
        public IEnumerable<People> Get()
        {
            return peoplelist; 
        }

        // GET: api/People/5
        public People Get(int id)
        {
            for (int i = 0; i < peoplelist.Count; i++)
            {
                if (peoplelist[i].PersonID == id)
                {
                    return peoplelist[i];
                }
            }
            return null;
        }

        // POST: api/People
        public void Post([FromBody]People value)
        {
            //replace peopleid with the id that is the latest this will ensure that the id is unique
            value.PersonID = peoplelist[peoplelist.Count].PersonID++;
            peoplelist.Add(value);
        }

        // PUT: api/People/5
        public void Put(int id, [FromBody]People value)
        {
            for (int i = 0; i <= peoplelist.Count; i++)
            {
                if (peoplelist[i].PersonID == id)
                {
                    peoplelist[i].FirstName = value.FirstName;
                    peoplelist[i].LastName = value.LastName;
                    peoplelist[i].OfficeNumber = value.OfficeNumber;
                    peoplelist[i].MobileNumber = value.MobileNumber;
                    peoplelist[i].Email = value.Email;
                    peoplelist[i].RegionalManagerPosition = value.RegionalManagerPosition;
                    peoplelist[i].BusinessAnalystPosition = value.BusinessAnalystPosition;
                    peoplelist[i].LocalITPosition = value.LocalITPosition; 
                }
            }
        }

        // DELETE: api/People/5
        public void Delete(int id)
        {
            for (int i = 0; i <= peoplelist.Count; i++)
            {
                if (peoplelist[i].PersonID == id)
                {
                    peoplelist.Remove(peoplelist[i]);
                    break;
                }
            }
        }
    }
}
