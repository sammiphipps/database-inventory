﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DatabaseInventoryWebAPI.Models
{
    public class Server
    {
        public int ServerID { get; set; }
        public int PlantID { get; set; }
        public string IPAddress { get; set; }
        public string ServerType { get; set; }
        public string DatabaseName { get; set; }
        public string DatabaseUserName { get; set; }
        public string DatabasePassword { get; set; }
    }
}