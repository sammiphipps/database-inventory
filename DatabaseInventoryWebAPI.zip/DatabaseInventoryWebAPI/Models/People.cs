﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DatabaseInventoryWebAPI.Models
{
    public class People
    {
        public int PersonID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string OfficeNumber { get; set; }
        public string MobileNumber { get; set; }
        public string Email { get; set; }
        public bool RegionalManagerPosition { get; set; }
        public bool BusinessAnalystPosition { get; set; }
        public bool LocalITPosition { get; set; }
    }
}